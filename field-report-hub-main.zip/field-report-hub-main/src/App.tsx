import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ReportsList from "./pages/ReportsList";
import ReportForm from "./pages/ReportForm";
import ReportDetail from "./pages/ReportDetail";
import QrCodeScanner from "./pages/QrCodeScanner";
import SearchPage from "./pages/SearchPage";
import ClientsPage from "./pages/ClientsPage";
import EquipmentsPage from "./pages/EquipmentsPage";
import VehiclesPage from "./pages/VehiclesPage";
import UsersPage from "./pages/UsersPage";
import SettingsPage from "./pages/SettingsPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/relatorios" element={<ReportsList />} />
          <Route path="/relatorios/novo" element={<ReportForm />} />
          <Route path="/relatorios/:id" element={<ReportDetail />} />
          <Route path="/relatorios/:id/editar" element={<ReportForm />} />
          <Route path="/qrcode" element={<QrCodeScanner />} />
          <Route path="/buscar" element={<SearchPage />} />
          <Route path="/clientes" element={<ClientsPage />} />
          <Route path="/equipamentos" element={<EquipmentsPage />} />
          <Route path="/veiculos" element={<VehiclesPage />} />
          <Route path="/usuarios" element={<UsersPage />} />
          <Route path="/configuracoes" element={<SettingsPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
