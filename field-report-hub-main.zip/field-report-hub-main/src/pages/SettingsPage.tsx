import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Settings, Save } from "lucide-react";

export default function SettingsPage() {
  return (
    <AppLayout>
      <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-4">
        <h1 className="text-2xl font-bold flex items-center gap-2"><Settings className="h-6 w-6 text-primary" />Configurações</h1>
        
        <Card>
          <CardHeader><CardTitle className="text-base">Google Apps Script</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>URL do Web App (Apps Script)</Label>
              <Input placeholder="https://script.google.com/macros/s/..." />
              <p className="text-xs text-muted-foreground mt-1">Cole a URL do seu Google Apps Script publicado como Web App.</p>
            </div>
            <div>
              <Label>ID da Pasta do Google Drive (Fotos)</Label>
              <Input placeholder="ID da pasta no Google Drive" />
            </div>
            <Button><Save className="h-4 w-4 mr-2" />Salvar</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Empresa</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Nome da Empresa</Label><Input placeholder="Sua Empresa Ltda" /></div>
            <div><Label>CNPJ</Label><Input placeholder="00.000.000/0001-00" /></div>
            <div><Label>Telefone</Label><Input placeholder="(00) 0000-0000" /></div>
            <Button><Save className="h-4 w-4 mr-2" />Salvar</Button>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
