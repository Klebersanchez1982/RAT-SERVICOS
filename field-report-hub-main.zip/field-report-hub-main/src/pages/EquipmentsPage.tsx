import { useEffect, useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Wrench } from "lucide-react";
import { getEquipments } from "@/lib/api-service";
import { Equipment } from "@/lib/types";

export default function EquipmentsPage() {
  const [equipments, setEquipments] = useState<Equipment[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => { getEquipments().then(setEquipments); }, []);

  const filtered = equipments.filter(e =>
    e.descricao.toLowerCase().includes(search.toLowerCase()) ||
    e.numeroSerie.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AppLayout>
      <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold flex items-center gap-2"><Wrench className="h-6 w-6 text-primary" />Equipamentos</h1>
          <Button><Plus className="h-4 w-4 mr-2" />Novo</Button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Buscar equipamento ou série..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <div className="space-y-3">
          {filtered.map(e => (
            <Card key={e.id}>
              <CardContent className="p-4">
                <h3 className="font-semibold">{e.descricao}</h3>
                <p className="text-sm text-muted-foreground">{e.clienteNome}</p>
                <div className="grid grid-cols-2 gap-2 mt-2 text-xs text-muted-foreground">
                  <span>Marca: {e.marca}</span>
                  <span>Modelo: {e.modelo}</span>
                  <span className="font-mono">Série: {e.numeroSerie}</span>
                  <span>Local: {e.localizacao}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
