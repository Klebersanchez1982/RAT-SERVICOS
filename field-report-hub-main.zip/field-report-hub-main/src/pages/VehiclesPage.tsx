import { useEffect, useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Car } from "lucide-react";
import { getVehicles } from "@/lib/api-service";
import { Vehicle } from "@/lib/types";

export default function VehiclesPage() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);

  useEffect(() => { getVehicles().then(setVehicles); }, []);

  return (
    <AppLayout>
      <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold flex items-center gap-2"><Car className="h-6 w-6 text-primary" />Veículos</h1>
          <Button><Plus className="h-4 w-4 mr-2" />Novo</Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {vehicles.map(v => (
            <Card key={v.id}>
              <CardContent className="p-4">
                <h3 className="font-semibold">{v.descricao}</h3>
                <p className="text-sm text-muted-foreground">{v.modelo} • {v.ano}</p>
                <p className="text-sm font-mono font-medium mt-1">{v.placa}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
