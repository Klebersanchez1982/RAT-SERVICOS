import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Edit, Printer } from "lucide-react";
import { getReportById } from "@/lib/api-service";
import { Report } from "@/lib/types";
import { Separator } from "@/components/ui/separator";

export default function ReportDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [report, setReport] = useState<Report | null>(null);

  useEffect(() => {
    if (id) getReportById(id).then(r => setReport(r || null));
  }, [id]);

  if (!report) return <AppLayout><div className="p-6 text-center text-muted-foreground">Carregando...</div></AppLayout>;

  const canEdit = report.status === 'rascunho' || report.status === 'aberto';

  return (
    <AppLayout>
      <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}><ArrowLeft className="h-4 w-4" /></Button>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold font-mono">{report.numero}</h1>
                <StatusBadge status={report.status} />
              </div>
              <p className="text-sm text-muted-foreground">{report.dataAbertura} às {report.horaAbertura}</p>
            </div>
          </div>
          <div className="flex gap-2">
            {canEdit && <Button size="sm" onClick={() => navigate(`/relatorios/${id}/editar`)}><Edit className="h-4 w-4 mr-1" />Editar</Button>}
            <Button size="sm" variant="outline"><Printer className="h-4 w-4 mr-1" />PDF</Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Informações Gerais</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Tipo</span><span className="capitalize font-medium">{report.tipoManutencao}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Técnico</span><span className="font-medium">{report.tecnicoNome}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Cliente</span><span className="font-medium">{report.clienteNome}</span></div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle className="text-base">Equipamento</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Descrição</span><span className="font-medium">{report.equipamentoDescricao}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">N° Série</span><span className="font-mono">{report.numeroSerie}</span></div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle className="text-base">Detalhes do Serviço</CardTitle></CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div><p className="text-muted-foreground mb-1">Problema Relatado</p><p>{report.problemaRelatado || '—'}</p></div>
            <Separator />
            <div><p className="text-muted-foreground mb-1">Diagnóstico</p><p>{report.diagnostico || '—'}</p></div>
            <Separator />
            <div><p className="text-muted-foreground mb-1">Serviço Executado</p><p>{report.servicoExecutado || '—'}</p></div>
            {report.informacoesAdicionais && (<><Separator /><div><p className="text-muted-foreground mb-1">Informações Adicionais</p><p>{report.informacoesAdicionais}</p></div></>)}
          </CardContent>
        </Card>

        {report.pecas.length > 0 && (
          <Card>
            <CardHeader><CardTitle className="text-base">Peças Utilizadas</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2">
                {report.pecas.map(p => (
                  <div key={p.id} className="flex justify-between text-sm p-2 bg-muted/50 rounded">
                    <span>{p.descricao}</span><span className="font-medium">Qtd: {p.quantidade}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader><CardTitle className="text-base">Deslocamento e Despesas</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="grid grid-cols-2 gap-2">
              <div className="flex justify-between"><span className="text-muted-foreground">Horas</span><span className="font-medium">{report.horasTrabalho}h</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Veículo</span><span className="font-medium">{report.veiculoDescricao} {report.placa}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Saída</span><span className="font-medium">{report.deslocamentoIda || '—'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Retorno</span><span className="font-medium">{report.deslocamentoVolta || '—'}</span></div>
            </div>
            <Separator />
            <div className="grid grid-cols-3 gap-2">
              <div className="text-center p-2 bg-muted/50 rounded"><p className="text-muted-foreground text-xs">Pedágio</p><p className="font-medium">R$ {report.pedagio.toFixed(2)}</p></div>
              <div className="text-center p-2 bg-muted/50 rounded"><p className="text-muted-foreground text-xs">Refeição</p><p className="font-medium">R$ {report.refeicao.toFixed(2)}</p></div>
              <div className="text-center p-2 bg-muted/50 rounded"><p className="text-muted-foreground text-xs">Estadia</p><p className="font-medium">R$ {report.estadia.toFixed(2)}</p></div>
            </div>
          </CardContent>
        </Card>

        <p className="text-xs text-muted-foreground text-center pb-6">
          Criado por {report.criadoPor} {report.editadoPor && `• Editado por ${report.editadoPor}`}
        </p>
      </div>
    </AppLayout>
  );
}
