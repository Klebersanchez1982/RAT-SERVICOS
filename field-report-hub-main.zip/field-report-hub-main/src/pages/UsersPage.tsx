import { useEffect, useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Users } from "lucide-react";
import { getUsers } from "@/lib/api-service";
import { User } from "@/lib/types";

const roleLabels: Record<string, string> = {
  admin: 'Administrador',
  tecnico_interno: 'Técnico Interno',
  tecnico_externo: 'Técnico Externo',
  consulta: 'Consulta',
};

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => { getUsers().then(setUsers); }, []);

  return (
    <AppLayout>
      <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold flex items-center gap-2"><Users className="h-6 w-6 text-primary" />Usuários</h1>
          <Button><Plus className="h-4 w-4 mr-2" />Novo</Button>
        </div>
        <div className="space-y-3">
          {users.map(u => (
            <Card key={u.id}>
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">{u.nome}</h3>
                  <p className="text-sm text-muted-foreground">{u.email}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{roleLabels[u.perfil]}</Badge>
                  <Badge variant={u.ativo ? "default" : "destructive"}>{u.ativo ? 'Ativo' : 'Inativo'}</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
