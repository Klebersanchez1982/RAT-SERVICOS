/**
 * Camada de serviço para integração com Google Apps Script.
 * Atualmente usa dados mock. Para integrar com Google Sheets,
 * substitua as funções por chamadas fetch() ao URL do Apps Script.
 * 
 * Exemplo de integração:
 * const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/SEU_ID/exec';
 * 
 * async function fetchData(action: string, params?: any) {
 *   const response = await fetch(`${APPS_SCRIPT_URL}?action=${action}`, {
 *     method: 'POST',
 *     body: JSON.stringify(params),
 *   });
 *   return response.json();
 * }
 */

import { mockClients, mockEquipments, mockVehicles, mockReports, mockUsers, currentUser } from './mock-data';
import { Client, Equipment, Vehicle, Report, User, ReportStatus } from './types';

// Simula delay de rede
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export async function getClients(): Promise<Client[]> {
  await delay(300);
  return [...mockClients];
}

export async function getEquipments(clienteId?: string): Promise<Equipment[]> {
  await delay(300);
  if (clienteId) return mockEquipments.filter(e => e.clienteId === clienteId);
  return [...mockEquipments];
}

export async function getEquipmentByQrCode(qrCode: string): Promise<Equipment | undefined> {
  await delay(300);
  return mockEquipments.find(e => e.qrCode === qrCode || e.numeroSerie === qrCode);
}

export async function getEquipmentHistory(equipamentoId: string): Promise<Report[]> {
  await delay(300);
  return mockReports.filter(r => r.equipamentoId === equipamentoId);
}

export async function getVehicles(): Promise<Vehicle[]> {
  await delay(300);
  return [...mockVehicles];
}

export async function getReports(filters?: { status?: ReportStatus; tecnicoId?: string }): Promise<Report[]> {
  await delay(300);
  let results = [...mockReports];
  if (filters?.status) results = results.filter(r => r.status === filters.status);
  if (filters?.tecnicoId) results = results.filter(r => r.tecnicoId === filters.tecnicoId);
  return results;
}

export async function getReportById(id: string): Promise<Report | undefined> {
  await delay(300);
  return mockReports.find(r => r.id === id);
}

export async function saveReport(report: Partial<Report>): Promise<Report> {
  await delay(500);
  const now = new Date();
  if (report.id) {
    const index = mockReports.findIndex(r => r.id === report.id);
    if (index >= 0) {
      mockReports[index] = { ...mockReports[index], ...report, editadoPor: currentUser.nome };
      return mockReports[index];
    }
  }
  const newReport: Report = {
    id: String(mockReports.length + 1),
    numero: `RAT-${now.getFullYear()}-${String(mockReports.length + 1).padStart(4, '0')}`,
    dataAbertura: now.toISOString().split('T')[0],
    horaAbertura: now.toTimeString().slice(0, 5),
    status: 'rascunho',
    fotos: [],
    pecas: [],
    criadoPor: currentUser.nome,
    editadoPor: '',
    ...report,
  } as Report;
  mockReports.push(newReport);
  return newReport;
}

export async function getUsers(): Promise<User[]> {
  await delay(300);
  return [...mockUsers];
}

export function getCurrentUser(): User {
  return currentUser;
}

export async function searchReports(query: string): Promise<Report[]> {
  await delay(300);
  const q = query.toLowerCase();
  return mockReports.filter(r =>
    r.numero.toLowerCase().includes(q) ||
    r.clienteNome.toLowerCase().includes(q) ||
    r.numeroSerie.toLowerCase().includes(q) ||
    r.equipamentoDescricao.toLowerCase().includes(q)
  );
}
