export type UserRole = 'admin' | 'tecnico_interno' | 'tecnico_externo' | 'consulta';

export interface User {
  id: string;
  nome: string;
  email: string;
  perfil: UserRole;
  ativo: boolean;
}

export interface Client {
  id: string;
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  endereco: string;
  cidade: string;
  estado: string;
  telefone: string;
  email: string;
  contato: string;
}

export interface Equipment {
  id: string;
  clienteId: string;
  clienteNome: string;
  descricao: string;
  marca: string;
  modelo: string;
  numeroSerie: string;
  localizacao: string;
  qrCode: string;
}

export interface Vehicle {
  id: string;
  descricao: string;
  placa: string;
  modelo: string;
  ano: string;
}

export type ReportStatus = 'rascunho' | 'aberto' | 'em_andamento' | 'finalizado' | 'fechado';
export type MaintenanceType = 'corretiva' | 'preventiva' | 'instalacao' | 'treinamento' | 'vistoria';
export type PhotoCategory = 'antes' | 'durante' | 'depois';

export interface ReportPhoto {
  id: string;
  relatorioId: string;
  url: string;
  categoria: PhotoCategory;
  descricao: string;
}

export interface ReportPart {
  id: string;
  descricao: string;
  quantidade: number;
  observacao: string;
}

export interface Report {
  id: string;
  numero: string; // RAT-2025-0001
  dataAbertura: string;
  horaAbertura: string;
  tecnicoId: string;
  tecnicoNome: string;
  tipoManutencao: MaintenanceType;
  clienteId: string;
  clienteNome: string;
  equipamentoId: string;
  equipamentoDescricao: string;
  numeroSerie: string;
  problemaRelatado: string;
  diagnostico: string;
  servicoExecutado: string;
  pecas: ReportPart[];
  informacoesAdicionais: string;
  horasTrabalho: number;
  deslocamentoIda: string;
  deslocamentoVolta: string;
  veiculoId: string;
  veiculoDescricao: string;
  placa: string;
  pedagio: number;
  refeicao: number;
  estadia: number;
  status: ReportStatus;
  fotos: ReportPhoto[];
  criadoPor: string;
  editadoPor: string;
  dataFinalizacao?: string;
}

export interface EquipmentHistory {
  relatorioNumero: string;
  data: string;
  tecnico: string;
  problema: string;
  servico: string;
  status: ReportStatus;
}
